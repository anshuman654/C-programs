 #include<stdio.h>
int main()
{
int a,b,sub;
printf("enter 2 numbers \n");
scanf("%d%d",&a,&b);

sub=a+~b+1;

printf("sub of %d a %d is %d \n",a,a,sub);
return 0;
}

