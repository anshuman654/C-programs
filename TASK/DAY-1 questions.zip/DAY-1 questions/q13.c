#include<stdio.h>
int main()
{
int a,b,s=0,i;
printf("\nEnter two number");
scanf("%d%d",&a,&b);
for(i=1;i<=b;i++){
s=s+a;
}
printf("\n Result=%d",s);
return 0;
}
