#include <stdio.h>
void checkEvenOdd(int n) {
if (n & 1)
printf("Odd\n");
else
printf("Even\n");
}
int main() {
int num;
printf("Enter a number: ");
scanf("%d", &num);
checkEvenOdd(num);
return 0;
}

