#include <stdio.h>
int main() {
long long num1 = 1000000000000;
long long num2 = 5000000000000;
printf("Value of num1: %lld\n", num1);
printf("Value of num2: %lld\n", num2);
long long sum = num1 + num2;
printf("Sum of num1 and num2: %lld\n", sum);
return 0;
}


