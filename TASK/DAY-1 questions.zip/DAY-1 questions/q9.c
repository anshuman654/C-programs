#include <stdio.h>
int main() {
int num1, num2, choice;
printf("Enter two numbers: ");
scanf("%d %d", &num1, &num2);
printf("Select operation:\n");
printf("1. Add\n");
printf("2. Subtract\n");
printf("3. Multiply\n");
printf("4. Divide\n");
scanf("%d", &choice);
switch (choice) {
case 1:
printf("Result: %d\n", num1 + num2);
break;
case 2:
printf("Result: %d\n", num1 - num2);
break;
case 3:
printf("Result: %d\n", num1 * num2);
break;
case 4:
if (num2 != 0)
printf("Result: %.2f\n", (float)num1 / num2);
else
printf("Error! Division by zero.\n");
break;
default:
printf("Invalid choice\n");
}
return 0;
}

